package com.example.jessicamegaro_weightlossapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public class DBHandler extends SQLiteOpenHelper {
    private static final String DB_NAME = "weightappdb";
    private static final String LOGIN_TABLE = "logins";
    private static final String LOGIN_EMAIL = "email";
    private static final String LOGIN_PASSWORD = "password";
    private static final String SETTINGS_TABLE = "settings";
    private static final String SETTINGS_NAME = "name";
    private static final String SETTINGS_VALUE = "value";
    private static final String WEIGHT_TABLE = "weight_log";
    private static final String WEIGHT_DATETIME = "log_datetime";
    private static final String WEIGHT_MEASUREMENT = "log_measurement";
    private static final String WEIGHT_UNIT = "log_unit";
    private static final int DB_VERSION = 1;


    public DBHandler(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = String.format(Locale.ENGLISH,
                "CREATE TABLE %s(" +
                  "ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                  "%s TEXT," +
                  "%s TEXT)",
                LOGIN_TABLE, LOGIN_EMAIL, LOGIN_PASSWORD);
        db.execSQL(query);

        query = String.format(Locale.ENGLISH,
                "CREATE TABLE %s(%s TEXT PRIMARY KEY, %s TEXT)",
                SETTINGS_TABLE, SETTINGS_NAME, SETTINGS_VALUE
        );
        db.execSQL(query);

        query = String.format(Locale.ENGLISH,
                "CREATE TABLE %s(" +
                "ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "%s TEXT, " + // LOG DATETIME
                "%s REAL, " + // Weight
                " %s TEXT)",
                WEIGHT_TABLE, WEIGHT_DATETIME, WEIGHT_MEASUREMENT, WEIGHT_UNIT
        );
        db.execSQL(query);

        ContentValues values = new ContentValues();
        values.put(SETTINGS_NAME, "SMSNotices");
        values.put(SETTINGS_VALUE, "NO");
        db.insert(SETTINGS_TABLE, null, values);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public void addWeighIn(ZonedDateTime time, float weight, WeighIn.WeightUnit unit) {
        ZonedDateTime zdt = time.withZoneSameInstant(ZoneId.of("UTC"));
        String strDate = zdt.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        System.out.println("Date: " + strDate);

        ContentValues values = new ContentValues();
        values.put(WEIGHT_DATETIME, zdt.toString());
        values.put(WEIGHT_MEASUREMENT, weight);
        values.put(WEIGHT_UNIT, unit.toString());

        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(WEIGHT_TABLE, null, values);
        db.close();
    }

    public void deleteWeighIn(WeighIn weighIn) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(WEIGHT_TABLE, "ID = ?", new String[]{String.format("%d", weighIn.getId())});
        db.close();
    }

    public ArrayList<WeighIn> getWeighIns() {
        ArrayList<WeighIn> weighins = new ArrayList<WeighIn>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                WEIGHT_TABLE,
                new String[]{"ID", WEIGHT_DATETIME, WEIGHT_MEASUREMENT, WEIGHT_UNIT},
                null,
                null,
                null,
                null,
                String.format("datetime(%s)", WEIGHT_DATETIME)
        );
        while (cursor.moveToNext()) {
            weighins.add(new WeighIn(cursor));
        }

        cursor.close();
        return weighins;
    }

    public long weighInCount() {
        SQLiteDatabase db = this.getReadableDatabase();
        return DatabaseUtils.queryNumEntries(db, WEIGHT_TABLE);
    }

    public WeighIn getNthWeighIn(int position) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                WEIGHT_TABLE,
                new String[]{"ID", WEIGHT_DATETIME, WEIGHT_MEASUREMENT, WEIGHT_UNIT},
                null,
                null,
                null,
                null,
                String.format("datetime(%s) DESC", WEIGHT_DATETIME),
                String.format("%d,1", position)
        );
        WeighIn weighIn = null;
        if (cursor.moveToNext()) {
            weighIn = new WeighIn(cursor);
        }

        cursor.close();
        return weighIn;
    }

    public String getSetting(String name) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                SETTINGS_TABLE,
                new String[]{SETTINGS_VALUE},
                SETTINGS_NAME + " = ?",
                new String[]{name},
                null,
                null,
                null
        );
        String value = null;
        if (cursor.moveToFirst()) {
            value = cursor.getString(0);
        }
        cursor.close();
        return value;
    }

    public void setSetting(String name, String value) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        System.out.println("Setting " + name + " = " + value);
        values.put(SETTINGS_NAME, name);
        values.put(SETTINGS_VALUE, value);
        db.update(SETTINGS_TABLE, values, String.format("%s = ?", SETTINGS_NAME), new String[]{name});
        db.close();
    }

    public void addLogin(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(LOGIN_EMAIL, email);
        values.put(LOGIN_PASSWORD, password); // TODO: Hash.

        db.insert(LOGIN_TABLE, null, values);

        db.close();
    }

    public Login findLogin(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                LOGIN_TABLE,
                new String[]{"ID", LOGIN_EMAIL, LOGIN_PASSWORD},
                LOGIN_EMAIL + " = ?",
                new String[]{email},
                null,
                null,
                null
        );

        Login login = null;
        if (cursor.moveToFirst()) {
            login = new Login(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2)
            );
        }
        cursor.close();
        return login;
    }

    public Login findLogin(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                LOGIN_TABLE,
                new String[]{"ID", LOGIN_EMAIL, LOGIN_PASSWORD},
                LOGIN_EMAIL + " = ? and " + LOGIN_PASSWORD + " = ?",
                new String[]{email, password},
                null,
                null,
                null
        );

        Login login = null;
        if (cursor.moveToFirst()) {
            login = new Login(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getString(2)
            );
        }
        cursor.close();
        return login;
    }
}
