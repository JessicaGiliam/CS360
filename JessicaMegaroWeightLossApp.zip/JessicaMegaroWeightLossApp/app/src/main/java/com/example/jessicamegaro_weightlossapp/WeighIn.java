package com.example.jessicamegaro_weightlossapp;

import android.database.Cursor;

import java.time.ZonedDateTime;

public class WeighIn {
    public enum WeightUnit { Pounds, Kilograms };

    private long id = 0;
    private ZonedDateTime time = null;
    private float weight = 0.0f;
    private WeightUnit unit = WeightUnit.Pounds;
    public WeighIn(ZonedDateTime time, float weight, WeightUnit unit) {
        this.time = time;
        this.weight = weight;
        this.unit = unit;
    }

    public WeighIn(Cursor cursor) {
        this.id = cursor.getLong(0);
        String dateTime = cursor.getString(1);
        this.time = ZonedDateTime.parse(dateTime);
        this.weight = cursor.getFloat(2);
        String unit = cursor.getString(3);
        this.unit = WeightUnit.valueOf(unit);
    }

    public long getId() {
        return id;
    }

    public ZonedDateTime getDateTime() {
        return time;
    }

    public float getWeight() {
        return weight;
    }

    public WeightUnit getUnit() {
        return unit;
    }
}
