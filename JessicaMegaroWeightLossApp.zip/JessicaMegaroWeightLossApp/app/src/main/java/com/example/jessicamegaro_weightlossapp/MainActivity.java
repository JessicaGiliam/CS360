package com.example.jessicamegaro_weightlossapp;

import android.content.DialogInterface;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;

import androidx.navigation.ui.AppBarConfiguration;

import com.example.jessicamegaro_weightlossapp.databinding.AddWeighinBinding;
import com.example.jessicamegaro_weightlossapp.databinding.LoginBinding;
import com.example.jessicamegaro_weightlossapp.databinding.SettingsBinding;
import com.example.jessicamegaro_weightlossapp.databinding.WeightGridBinding;

import android.view.Menu;
import android.view.MenuItem;

import java.time.ZonedDateTime;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private AppBarConfiguration appBarConfiguration;
    //private ActivityMainBinding binding;
    private LoginBinding loginBinding;
    private WeightGridBinding weightGridBinding;
    private AddWeighinBinding weighinBinding;
    private WeightGridAdapter weightGridAdapter;

    private SettingsBinding settingsBinding;
    private DBHandler dbHandler;
    private Login login = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        dbHandler = new DBHandler(getApplicationContext());

        loginBinding = LoginBinding.inflate(getLayoutInflater());
        setContentView(loginBinding.getRoot());

        loginBinding.registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String login = loginBinding.userNameText.getText().toString();
                String password = loginBinding.userPassword.getText().toString();
                // First check to see if we have an account with the same login.
                if (dbHandler.findLogin(login) != null) {
                    loginBinding.alertTextEdit.setText("Account with that email exists already.");
                } else {
                    dbHandler.addLogin(login, password);
                    loginBinding.alertTextEdit.setText("Account created.");
                }
            }
        });

        loginBinding.loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = loginBinding.userNameText.getText().toString();
                String pass = loginBinding.userPassword.getText().toString();
                login = dbHandler.findLogin(email, pass);
                if (login == null) {
                    loginBinding.alertTextEdit.setText("Invalid login and/or password.");
                } else {
                    setContentView(weightGridBinding.getRoot());
                }
            }
        });

        weightGridAdapter = new WeightGridAdapter(getApplicationContext(), dbHandler, this);
        weightGridBinding = WeightGridBinding.inflate(getLayoutInflater());
        weightGridBinding.weighInGrid.setAdapter(weightGridAdapter);
        weightGridBinding.addWeighInButton.setOnClickListener(this);

        weighinBinding = AddWeighinBinding.inflate(getLayoutInflater());
        weighinBinding.weighInOk.setOnClickListener(this);
        weighinBinding.weighInCancel.setOnClickListener(this);

        settingsBinding = SettingsBinding.inflate(getLayoutInflater());
        settingsBinding.applyButton.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            String value = dbHandler.getSetting("SMSNotices");
            System.out.println("SMSNotices: " + value);
            settingsBinding.smsNotificationSwitch.setChecked(value.equals("YES"));
            setContentView(settingsBinding.getRoot());
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.addWeighInButton) {
            setContentView(weighinBinding.getRoot());
        } else if (v.getId() == R.id.weighInOk) {
            float weight = Float.parseFloat(weighinBinding.weightNumberInput.getText().toString());
            WeighIn.WeightUnit unit = weighinBinding.weighInPounds.isChecked() ? WeighIn.WeightUnit.Pounds : WeighIn.WeightUnit.Kilograms;
            dbHandler.addWeighIn(ZonedDateTime.now(), weight, unit);
            setContentView(weightGridBinding.getRoot());
            weightGridAdapter.notifyDataSetChanged();
            weightGridBinding.weighInGrid.invalidate();
        } else if (v.getId() == R.id.weighInCancel) {
            setContentView(weightGridBinding.getRoot());
            weightGridBinding.weighInGrid.invalidate();
        } else if (v.getId() == R.id.deleteButton) {
            WeighIn weighIn = (WeighIn)v.getTag();
            dbHandler.deleteWeighIn(weighIn);
            weightGridAdapter.notifyDataSetChanged();
            weightGridBinding.weighInGrid.invalidate();
        } else if (v.getId() == R.id.applyButton) {
            boolean checked = settingsBinding.smsNotificationSwitch.isChecked();
            dbHandler.setSetting("SMSNotices", checked?"YES":"NO");
            if (login == null) {
                setContentView(loginBinding.getRoot());
            } else {
                setContentView(weightGridBinding.getRoot());
            }
        }
    }
}