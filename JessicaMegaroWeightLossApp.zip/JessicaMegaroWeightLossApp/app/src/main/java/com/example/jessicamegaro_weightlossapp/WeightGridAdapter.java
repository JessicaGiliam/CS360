package com.example.jessicamegaro_weightlossapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import com.example.jessicamegaro_weightlossapp.databinding.WeighinItemBinding;


public class WeightGridAdapter extends BaseAdapter {
    private Context context = null;
    private DBHandler dbHandler = null;
    private ArrayList<WeighIn> weighIns = null;
    private LayoutInflater inflater = null;
    private View.OnClickListener handler = null;

    public WeightGridAdapter(Context context, DBHandler dbHandler, View.OnClickListener handler) {
        this.context = context;
        this.dbHandler = dbHandler;
        this.weighIns = dbHandler.getWeighIns();
        this.inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.weighIns = dbHandler.getWeighIns();
        this.handler = handler;
   }

    @Override
    public int getCount() {
        return (int)dbHandler.weighInCount();
    }

    @Override
    public Object getItem(int position) {
        return dbHandler.getNthWeighIn(position);
    }

    @Override
    public long getItemId(int position) {
        return dbHandler.getNthWeighIn(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
            convertView = inflater.inflate(R.layout.weighin_item, null);
        TextView timeText = convertView.findViewById(R.id.timeText);
        TextView weightText = convertView.findViewById(R.id.weightText);

        WeighIn weighin = dbHandler.getNthWeighIn(position);
        LocalDateTime ldt = weighin.getDateTime().toLocalDateTime();

        timeText.setText(ldt.format(DateTimeFormatter.ofPattern("eee MMM d, u")));
        weightText.setText(String.format(
                "%.2f %s",
                weighin.getWeight(),
                (weighin.getUnit() == WeighIn.WeightUnit.Pounds) ? "lb":"kg"
        ));
        Button deleteButton = convertView.findViewById(R.id.deleteButton);
        deleteButton.setTag(weighin);
        deleteButton.setOnClickListener(handler);

        return convertView;
    }
}
