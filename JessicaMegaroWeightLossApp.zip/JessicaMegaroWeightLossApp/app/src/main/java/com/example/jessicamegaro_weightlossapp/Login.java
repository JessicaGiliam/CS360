package com.example.jessicamegaro_weightlossapp;

public class Login {
    private int id;
    private String email;
    private String password;

    public Login(int id, String email, String password) {
        this.id = id;
        this.email = email;
        this.password = password;
    }
}
